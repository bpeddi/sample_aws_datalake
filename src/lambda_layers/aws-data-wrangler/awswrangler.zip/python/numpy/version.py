
# THIS FILE IS GENERATED FROM NUMPY SETUP.PY
#
# To compare versions robustly, use `numpy.lib.NumpyVersion`
short_version: str = '1.20.1'
version: str = '1.20.1'
full_version: str = '1.20.1'
git_revision: str = 'd7aa4085623b222058edb0ff38392c38c5e00c54'
release: bool = True

if not release:
    version = full_version
